</div>

<div id="footer">

  <!-- Footer Links -->
<!-- edited by Rahil
  <h5>Elsewhere</h5>
  <ul class="elsewhere">
    <?php wp_list_bookmarks('categorize=0&title_li=&category_name=footer&show_images=0'); ?>
  </ul>
-->

  <!-- Search 
<!-- edited by Rahil
  <div class="footerContent">
    <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
      <div id="search">
        <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
        <input type="submit" id="searchsubmit" value="Search" />
      </div>
    </form>
-->
    
    <p>&copy; <?php bloginfo('name'); ?>. Powered by <a href="http://wordpress.org/">WordPress</a> and <a href="http://jimbarraud.com/manifest/">Manifest</a></p>
  </div>
</div>

<?php wp_footer(); ?>

</body>
</html>