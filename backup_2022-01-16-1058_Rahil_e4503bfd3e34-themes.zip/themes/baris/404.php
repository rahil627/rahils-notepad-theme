<?php get_header(); ?>

	<div id="content">
		<div id="page">
	
	<h2><?php _e( 'Not Found', 'baris' ); ?></h2>
		<p><?php _e( 'Sorry, but the page you requested could not be found.', 'baris' ); ?></p>

		</div>
	</div>

<?php get_footer(); ?>