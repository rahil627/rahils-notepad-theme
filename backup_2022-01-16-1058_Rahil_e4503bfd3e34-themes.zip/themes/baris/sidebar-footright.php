<?php
	if ( is_active_sidebar( 'right-foot-widget-area' ) ) : ?>

			<div class="sidebar-foot-right">
				<?php dynamic_sidebar( 'right-foot-widget-area' ); ?>
			</div>

<?php endif; ?>