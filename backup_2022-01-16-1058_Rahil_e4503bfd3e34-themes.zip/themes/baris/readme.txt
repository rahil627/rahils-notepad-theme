/***

Baris Theme by Malvouz
Visit http://www.malvouz.com/omega

***/


Credit:
Image Pattern (Debut-Light) by http://subtlepatterns.com/

License:
Baris WordPress Theme, Copyright 2013 WordPress.org
Baris is distributed under the terms of the GNU GPL